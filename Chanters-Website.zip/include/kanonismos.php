	<div class="col-md-9">
			<h1> Κανονισμπός Ιεροψαλτών </h1>
			<hr>
			<a href="http://sivkoukouzelis.gr/wp-content/uploads/2014/03/%CE%9A%CE%B1%CE%BD%CE%BF%CE%BD%CE%B9%CF%83%CE%BC%CF%8C%CF%82-%CE%99%CE%B5%CF%81%CE%BF%CF%88%CE%AC%CE%BB%CF%84%CE%BF%CF%85-176_2006-%CE%A6%CE%95%CE%9A-268_2006.pdf">
			Όλος ο κανονισμός εδώ!!</a>
			<hr>
			</div>