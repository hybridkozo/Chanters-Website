<?php

echo "den stalthike tpt";

?>