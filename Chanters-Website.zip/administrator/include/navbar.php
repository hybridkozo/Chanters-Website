<?php

header("Content-Type: text/html; charset=UTF-8");
echo '<div id="txtHint2">';
$administration->EditMenu();
echo '</div>';
?>