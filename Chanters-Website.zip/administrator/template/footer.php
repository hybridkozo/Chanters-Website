	<div class="footer" style="background-color:#1a1a1a;color:#cccccc;border-radius: 5px;">
		<div class="row">
			
			<div class="col-md-12">
			
			 <h1 style="text-align:center;"> Administrator Page</h1>
		</div>
		<div class="row">
			<div class="col-md-12">
				
			<p style="text-align:center;">© 2016 Σύλογος Ιεροψαλτών Αθηνών, designed by <a href="https://www.linkedin.com/in/ioannis-kozompolis-373406125">John Kozompolis</a> and George Emmanouil</p>
			
			</div>
		</div>
		</div>
	    </div>