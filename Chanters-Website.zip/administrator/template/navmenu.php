<h4> Menu </h4>
			<hr>
				<ul class="nav nav-pills nav-stacked">
					<li><a href="admin.php?action=users.php">Users</a></li>
					<li><a href="admin.php?action=articles.php">Articles</a></li>
					<li><a href="admin.php?action=navbar.php">Edit Navbar</a></li>
				</ul>