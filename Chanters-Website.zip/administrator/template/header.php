<div class="page-header" style="background-color:#1a1a1a;color:#cccccc;border-radius: 5px;">
		<h1 style="text-align:center;"> Chanters-Website</h1>
		<h3 style="text-align:right;margin-right:10px;"> Administrator Page</h3>
		<p style="text-align:right;margin-right:10px;">Διαχειριστής, <?= $administration->printusername(); echo " "; ?><a href="include/logout.php" ><span class="glyphicon glyphicon-log-out"></span> Αποσύνδεση</a></p>
	</div>