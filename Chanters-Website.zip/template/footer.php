		<div class="footer" style="background-color:#0d0d0d;color:#cccccc;border-radius: 5px;">
		<div class="row">
			<div class="col-md-4" >
			<h3 id='footertitles' style="margin:20px;font-style:italic; font-family: Times New Roman, Times, serif;"> Site Map </h3><hr>
			
			<?php
			$fgmembersite->SiteMap();
			?>
				
			</div>
			<div class="col-md-4">
			<h3 id='footertitles' style="margin:20px;font-style:italic; font-family: Times New Roman, Times, serif;"> Social Media </h3> <hr>
			
			
				<ul >
					<li id='list'><a class="footerlinks" href="https://www.facebook.com"><strong> Facebook</strong></a></li>
					<li id='list'><a class="footerlinks" href="http://www.twitter.com"><strong>Twitter</strong></a></li> 
					<li id='list'><a class="footerlinks" href="http://www.youtube.com"> <strong>Youtube</strong></a></li> 
					<li id='list'><a class="footerlinks" href="https://www.plus.google.com"><strong>Google+</strong></a></li> 
				</ul>
				
				
			</div>
			<div class="col-md-4">
			<h3 id='footertitles' style="margin:20px;font-style:italic; font-family: Times New Roman, Times, serif;"> Επικοινωνία </h3><hr>
			
				<p id="footertitles"><span class="glyphicon glyphicon-home"></span> Πραξιτέλους 236, Πειραιάς, Τ.Κ. 18633</p>
				<p id="footertitles"> <span class="glyphicons glyphicons-iphone"></span>+306971903121</p>
				<p id="footertitles"> <span class="glyphicons glyphicons-email"></span> g.kozompolis@gmail.com</p>
			
			</div>
			
		</div>
		<div class="row">
			<div class="col-md-12">
				<hr>
			<p style="text-align:center;">© 2016 Σύλογος Ιεροψαλτών Αθηνών, designed by <a href="https://gr.linkedin.com/in/ioannis-kozompolis-373406125">John Kozompolis</a> and George Emmanouil</p>
			
			</div>
		</div>
		</div>