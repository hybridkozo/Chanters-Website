<div class="page-header headerbackground" style="margin:0px; border-radius: 10px 10px 10px 10px;">
<div style="margin: 15px">
		
			
			</br>
			<h1 style="color:white;font-style:italic; font-family: Times New Roman, Times, serif;">
				<strong>Σύλογος Ιεροψαλτών</strong> 
			</h1>
			
			</br>
			</br>
			<p style="color:white;font-style:italic; font-family: Times New Roman, Times, serif;"><strong>"Ο Σύλογος Ιεροψαλτών είναι δίπλα σας από το 1924"</strong></p>
			</br>
			
			</div>
			
			</div>
